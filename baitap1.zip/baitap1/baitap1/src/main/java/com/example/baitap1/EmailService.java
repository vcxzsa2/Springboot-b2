package com.example.baitap1;

import org.springframework.stereotype.Component;

@Component
public class EmailService {
    public void sendEmail(String email, String message ){
        System.out.println("Tới: "+ email);
        System.out.println("Nội dung: " + message);
    }
}

