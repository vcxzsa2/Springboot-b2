package com.example.baitap1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Baitap1Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Baitap1Application.class, args);

		UserController usercontroller = context.getBean(UserController.class);
		usercontroller.registerUser("kien@example.com");
	}

}