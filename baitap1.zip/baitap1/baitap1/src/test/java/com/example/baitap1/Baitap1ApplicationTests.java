package com.example.baitap1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Baitap1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
