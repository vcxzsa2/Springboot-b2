package com.example.baitap5.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private SimpleDateFormat dateFormatter;

    public void createTask(String task) {
        String currentTime  = dateFormatter.format(new Date());
        taskRepository.save(task);
        System.out.println("Đã tạo nhiệm vụ: " + task + " lúc " + currentTime );
    }
}
