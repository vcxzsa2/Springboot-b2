package com.example.baitap5;

import com.example.baitap5.Task.TaskService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Baitap5Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Baitap5Application.class, args);

		TaskService taskService = context.getBean(TaskService.class);
		taskService.createTask("Học Spring với Annotation");
	}

}
