package com.example.baitap5.Task;


import org.springframework.stereotype.Component;

@Component
public class TaskRepository {
    public void save(String task) {
        System.out.println("Đang lưu nhiệm vụ: " + task);
    }
}