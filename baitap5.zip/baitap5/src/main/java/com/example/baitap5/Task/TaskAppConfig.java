package com.example.baitap5.Task;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.text.SimpleDateFormat;

@Configuration
public class TaskAppConfig {

    @Bean
    public SimpleDateFormat dateFormatter() {
        return new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
    }
}
