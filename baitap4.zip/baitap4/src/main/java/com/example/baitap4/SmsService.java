package com.example.baitap4;

import org.springframework.stereotype.Component;

public class SmsService implements MessageService{
    @Override
    public void sendMessage(String to) {
        System.out.println("Gui sms toi: " + to);
    }
}
