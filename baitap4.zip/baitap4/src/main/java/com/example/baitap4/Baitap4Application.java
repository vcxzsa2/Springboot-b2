package com.example.baitap4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Baitap4Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Baitap4Application.class, args);

		ServiceType type = context.getBean(ServiceType.class);

		type.notifyUser("gjdj");
	}

}
