package com.example.baitap4;

import org.springframework.context.annotation.Configuration;

public class EmailService implements MessageService{
    @Override
    public void sendMessage(String to) {
        System.out.println("Gui Email toi: " + to);
    }
}
