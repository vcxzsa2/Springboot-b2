package com.example.baitap4;

public interface MessageService {
    public void sendMessage(String to);
}
