package com.example.baitap4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Baitap4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
