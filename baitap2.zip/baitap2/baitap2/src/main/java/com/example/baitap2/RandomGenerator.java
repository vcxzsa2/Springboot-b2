package com.example.baitap2;

import java.util.Random;

public class RandomGenerator {
    private Random random = new Random();
    public int generate(){
        return random.nextInt(50);
    }
}
