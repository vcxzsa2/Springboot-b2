package com.example.baitap2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public RandomGenerator randomgenerator(){
        return new RandomGenerator();
    }
}
