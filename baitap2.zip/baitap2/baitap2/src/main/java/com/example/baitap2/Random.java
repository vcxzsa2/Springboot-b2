package com.example.baitap2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Random {
    @Autowired
    private RandomGenerator randomGenerator;

    public Random(RandomGenerator randomgenerator, RandomGenerator randomGenerator){
        this.randomGenerator = randomGenerator;
    }
    public void showNumber() {
        System.out.println("Số:" + randomGenerator.generate());
    }
}
