package com.example.baitap2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Baitap2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
