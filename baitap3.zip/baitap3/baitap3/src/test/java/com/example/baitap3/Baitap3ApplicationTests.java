package com.example.baitap3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Baitap3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
