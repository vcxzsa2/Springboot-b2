package com.example.service;

import org.springframework.stereotype.Component;

@Component
public class UserService {
    public void printUser(){
        System.out.println("UserService is here");
    }
}
