package com.example.baitap3;

import com.example.service.ProductService;
import com.example.service.UserService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@SpringBootApplication(scanBasePackages = "com.example.service")
public class Baitap3Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Baitap3Application.class, args);

		UserService userService = context.getBean(UserService.class);
		ProductService productService = context.getBean(ProductService.class);

		userService.printUser();
		productService.printProduct();
	}

}
