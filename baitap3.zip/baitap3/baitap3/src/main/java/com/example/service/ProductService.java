package com.example.service;

import org.springframework.stereotype.Component;

@Component
public class ProductService {
    public void printProduct(){
        System.out.println("Product is here");
    }
}
